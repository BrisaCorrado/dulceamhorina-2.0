document.addEventListener('DOMContentLoaded', () => {
    
    // 1. Header Scroll
    const header = document.getElementById('header');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // 2. Menú Móvil
    const menuToggle = document.getElementById('menu-toggle');
    const navMenu = document.getElementById('nav-menu');
    const navLinks = document.querySelectorAll('.nav-menu a');

    if(menuToggle) {
        menuToggle.addEventListener('click', () => {
            menuToggle.classList.toggle('active');
            navMenu.classList.toggle('active');
            document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : '';
        });
    }

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            menuToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.style.overflow = '';
        });
    });

    // 3. Lógica del Pop-up (Modal) con mensaje profesional
    const productCards = document.querySelectorAll('.product-card');
    const modal = document.getElementById('product-modal');
    const closeModal = document.querySelector('.close-modal');
    
    const modalImg = document.getElementById('modal-img');
    const modalTitle = document.getElementById('modal-title');
    const modalDesc = document.getElementById('modal-desc');
    const modalPrice = document.getElementById('modal-price');
    const modalWhatsapp = document.getElementById('modal-whatsapp');

    if(productCards.length > 0 && modal) {
        productCards.forEach(card => {
            card.addEventListener('click', () => {
                const imgSrc = card.getAttribute('data-img');
                const title = card.getAttribute('data-nombre');
                const desc = card.getAttribute('data-desc');
                const price = card.getAttribute('data-precio');

                modalImg.src = imgSrc;
                modalTitle.textContent = title;
                modalDesc.textContent = desc;
                modalPrice.textContent = price;

                // Mensaje profesional automatizado para WhatsApp
                const mensajeWA = encodeURIComponent(`Hola, estoy interesado en el producto: ${title}. ¿Podrían indicarme disponibilidad, formas de entrega y si tienen precios por volumen para empresas?`);
                modalWhatsapp.href = `https://wa.me/5491130971006?text=${mensajeWA}`;

                modal.classList.add('show');
                document.body.style.overflow = 'hidden';
            });
        });
    }

    if(closeModal) {
        closeModal.addEventListener('click', () => {
            modal.classList.remove('show');
            document.body.style.overflow = '';
        });
    }

    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('show');
            document.body.style.overflow = '';
        }
    });

    // 4. Lógica de Filtros de Categoría
    const filterBtns = document.querySelectorAll('.filter-btn');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const filterValue = btn.getAttribute('data-filter');

            productCards.forEach(card => {
                const category = card.getAttribute('data-category');
                
                if (filterValue === 'all' || filterValue === category) {
                    card.classList.remove('hide');
                    card.style.animation = 'none';
                    card.offsetHeight; 
                    card.style.animation = null; 
                } else {
                    card.classList.add('hide');
                }
            });
        });
    });
});